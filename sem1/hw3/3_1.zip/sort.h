#pragma once

void quickSort(int *numbers, int left, int right);
